<?php

return function () {
    app()->register('Barryvdh\Debugbar\ServiceProvider');
};
