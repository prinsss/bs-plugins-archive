'use strict';

$('input[name=register_with_player_name]').parents('tr').hide();
