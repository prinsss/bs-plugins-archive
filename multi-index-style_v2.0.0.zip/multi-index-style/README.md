# 多种首页样式插件
这是一个用于自定义 Blessing Skin Server 首页的插件。

这个插件原作者为 [@GPlane](https://github.com/g-plane)，现已由 @Little_Qiu 接手。

除非出现重大 Bug，这个插件很可能不会继续维护。
