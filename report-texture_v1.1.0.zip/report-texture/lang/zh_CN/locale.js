$.locales['zh_CN'].reportTexture = {
    MyReport: '我的举报',
    ManageReport: '举报管理',
    reportThis: '举报该材质',
    submitting:'提交中...',
    TID: '材质 TID',
    invalidTID: '无效的 TID',
    reportReason: '请填写举报原因',
    reportReasonExample: '色情，暴力内容等',

    status: {
        resolved: '处理完毕',
        rejected: '已被拒绝'
    },
};