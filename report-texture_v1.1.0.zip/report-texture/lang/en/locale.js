$.locales['en'].reportTexture = {
    MyReport: 'My Reports',
    ManageReport: 'Manage Reports',
    reportThis: 'Report this',
    submitting: 'Submitting...',
    TID: 'Texture TID',
    invalidTID: 'Invalid TID',
    reportReason: 'Please fill in the report reason',
    reportReasonExample: 'porn, violent...',

    status: {
        resolved: 'Resolved',
        rejected: 'Rejected'
    },
};
