/*
* @Author: printempw
* @Date:   2017-01-02 14:05:33
* @Last Modified by:   printempw
* @Last Modified time: 2017-01-02 14:19:26
*/

"use strict";

$.extend($.locales['en'], {
    'examplePlugin': {
        test: "JavaScript i18n test: English"
    }
});
