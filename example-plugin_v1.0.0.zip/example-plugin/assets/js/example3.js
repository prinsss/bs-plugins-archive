/*
* @Author: printempw
* @Date:   2017-01-08 16:00:21
* @Last Modified by:   printempw
* @Last Modified time: 2017-01-08 16:00:54
*/

'use strict';

console.info("示例：你只会在管理面板和皮肤库看到这行字");
