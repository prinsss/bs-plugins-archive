/*
* @Author: printempw
* @Date:   2017-01-08 16:00:21
* @Last Modified by:   printempw
* @Last Modified time: 2017-01-08 16:04:47
*/

'use strict';

console.warn("示例：我将被最先加载，因为我优先级最高");
